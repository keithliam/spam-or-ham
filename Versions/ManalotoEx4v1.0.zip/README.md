# Bag Of Words

## How to run

```
./main
```
package bagofwords;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Map;
import java.util.Arrays;

import java.util.HashMap;
import java.util.Scanner;

public class Main{
	public static void main(String[] args){
		System.out.print("Enter filename to read: ");
		String filename = (new Scanner(System.in)).nextLine();
		String file = new String();
		try{
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			String line = new String();
			while((line = reader.readLine()) != null) {
				file = file.concat(line + " ");
			}
		} catch(FileNotFoundException e){
			System.out.println("File not found");
		} catch(Exception e){
			System.out.println(e.getMessage());
		}

		file = file.toLowerCase().replaceAll("@|\\.|:|\\t|-|\\\\|/|\'", "");
		String[] words = file.split("([^a-zA-Z0-9]+)'*\\1*"); 
		int wordSize = words.length;

		HashMap<String, Integer> bagOfWords = new HashMap<String, Integer>();
		for(int i = 0; i < words.length; i++){
			if(bagOfWords.containsKey(words[i])) bagOfWords.replace(words[i], bagOfWords.get(words[i]) + 1);
			else bagOfWords.put(words[i], 1);
		}

		try{
			file = "Dictionary Size: " + bagOfWords.size() + "\nTotal Number of Words: " + wordSize;
			for(String key : bagOfWords.keySet()){
				file = file + "\n" + key + ": " + bagOfWords.get(key);
			}
			PrintWriter writer = new PrintWriter("output.txt", "UTF-8");
			writer.println(file);
			writer.close();
		} catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
# Bag Of Words
A naïve Bayesian Spam-Filtering AI.

## How to run

```
./main
```